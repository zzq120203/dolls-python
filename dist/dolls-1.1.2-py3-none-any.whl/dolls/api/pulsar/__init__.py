from .pulsar_cli import *
from .pulsar_admin import *


class Pulsar(object):

    def __init__(self, url: str, auth=None, issl: bool = False) -> None:
        if not url.startswith("pulsar"):
            if issl:
                url = "pulsar+ssl://" + url
            else:
                url = "pulsar://" + url
        self.__client = pulsar.Client(service_url=url, authentication=auth)

    def producer(self, topic: str, schema=schema.StringSchema(), max_message=1024 * 1024) -> PProducer:
        return PProducer(client=self.__client, topic=topic, schema=schema, max_message=max_message)

    def consumer(self, topic: str, sub_name: str, schema=StringSchema()) -> PConsumer:
        return PConsumer(client=self.__client, topic=topic, sub_name=sub_name, schema=schema)

    def close(self):
        self.__client.close()
