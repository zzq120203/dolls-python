# import pulsar
import urllib3
import json


class PulsarAdmin(object):
    def __init__(self, urls: str, user=None, password=None, topic=None, schema=None, http_port=None):
        self.urls = urls
        self.user = user
        self.password = password
        self.http_port = http_port
        self.topic = topic
        self.schema = schema

    def topic_msg(self, topic):
        urls = self.urls
        urls = urls.replace("pulsar://", "http://")
        strs = urls.split(":")
        port = strs[len(strs) - 1]
        urls = urls.replace(port, str(self.http_port))
        self.urls = urls + "/admin/v2/persistent/public/default/" + topic + "/stats"
        http = urllib3.PoolManager()
        req = http.request("get", self.urls)
        http.clear()
        return req.data.decode()

    # 删除topic
    def del_topic(self, topic):
        urls = self.urls
        urls = urls.replace("pulsar://", "http://")
        strs = urls.split(":")
        port = strs[len(strs) - 1]
        urls = urls.replace(port, str(self.http_port))
        self.urls = urls + "/admin/v2/persistent/public/default/" + topic
        http = urllib3.PoolManager()
        req = http.request("delete", self.urls)
        http.clear()
        return req.data.decode()

    # 删除订阅组
    def del_subscription(self, topic: str, subs: str):
        urls = self.urls
        urls = urls.replace("pulsar://", "http://")
        strs = urls.split(":")
        port = strs[len(strs) - 1]
        urls = urls.replace(port, str(self.http_port))
        self.urls = urls + "/admin/v2/persistent/public/default/" + topic + "/subscription/" + subs
        http = urllib3.PoolManager()
        req = http.request("delete", self.urls)
        http.clear()
        return req.data.decode()

    # 查看topic下的订阅组
    def get_subscriptions(self, topic: str):
        urls = self.urls
        urls = urls.replace("pulsar://", "http://")
        strs = urls.split(":")
        port = strs[len(strs) - 1]
        urls = urls.replace(port, str(self.http_port))
        self.urls = urls + "/admin/v2/persistent/public/default/" + topic + "/subscriptions"
        http = urllib3.PoolManager()
        req = http.request("get", self.urls)
        http.clear()
        return req.data.decode()

    # 挤压量
    def back_log_size(self, topic: str):
        s = self.topic_msg(topic)
        ss = json.loads(s)
        size = ss["backlogSize"]
        return size

    # 存储量
    def storage_size(self, topic: str):
        s = self.topic_msg(topic)
        ss = json.loads(s)
        size = ss["storageSize"]
        return size

    # 平均大小
    def average_size(self, topic: str):
        s = self.topic_msg(topic)
        ss = json.loads(s)
        size = ss["averageMsgSize"]
        return size

    # 生产速度
    def rate_in(self, topic: str):
        s = self.topic_msg(topic)
        ss = json.loads(s)
        size = ss["msgRateIn"]
        return size

    # 消费速度
    def rate_out(self, topic: str):
        s = self.topic_msg(topic)
        ss = json.loads(s)
        size = ss["msgRateout"]
        return size


if __name__ == '__main__':
    pass
