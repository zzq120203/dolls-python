# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : test.py
# @Time     : 2022/5/18 11:31

import sys
from uuid import uuid4

import pulsar
from pulsar.schema import schema

if __name__ == '__main__':
    topic = sys.argv[0]

    client = pulsar.Client(service_url="pulsar://172.16.67.29:16650")

for i in 1000:

    producer = client.create_producer(
        topic=topic,
        schema=schema.StringSchema(),
        batching_enabled=True,
        block_if_queue_full=True,
        batching_max_messages=3000)
    producer.send(str(uuid4()))

    print("send end")

    consumer = client.subscribe(
        topic=topic,
        subscription_name="test_airflow",
        schema=schema.StringSchema(),
        consumer_type=pulsar.ConsumerType.Shared,
    )

    d = consumer.receive()

    print(d.data())

    client.close()

    print("close")

