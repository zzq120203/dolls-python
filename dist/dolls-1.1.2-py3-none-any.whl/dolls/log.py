# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : log.py
# @Time     : 2022/6/16 10:58

try:
    from loguru import logger
except ImportError:
    import logging
    logger = logging.getLogger()
