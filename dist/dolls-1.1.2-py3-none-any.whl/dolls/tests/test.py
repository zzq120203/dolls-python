# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : Zhang Zhanqi
# @FILE     : test.py
# @Time     : 2021/6/9 18:31


import os
import sys
import uuid
from time import sleep
from pathlib import Path
import os

import requests

from dolls.pydis import RedisPool
from dolls.pysql.pool import SqlPool

if __name__ == '__main__':

    sql = SqlPool(host="192.168.101.66", port=19910, user='trino')

    result = sql.search("select * from mysql.lyh.person limit 10")

    print(result)

    for result in result:
        print("%s: %s" % (result['type'], result['date']))

    path = Path("file_name")  # image filename

    # 冒泡排序
