# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : test_config.py
# @Time     : 2022/4/25 18:24
from pathlib import Path

from dolls.configs.file_setting import BaseFileSettings


class Settings(BaseFileSettings):
    """
    配置文件
    """
    # 数据库配置
    PROJECT_NAME = ''

    class Config:
        conf_file = '../../config.yaml'


if __name__ == '__main__':
    settings = Settings()

    print(settings)
    print(BaseFileSettings())
