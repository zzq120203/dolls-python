import enum
import json

import graphene
import uvicorn
from fastapi import FastAPI
from starlette.graphql import GraphQLApp

from dolls.pydis import RedisPool

pool = RedisPool(urls=("localhost", 16379))
table = pool.table(table_name="datasource")

class DSTypeEnum(enum.Enum):
    file = 1
    redis = 2


class Datasource(graphene.ObjectType):
    ds_id = graphene.Int(description='数据id')
    ds_name = graphene.String(description='数据名称')
    ds_type = graphene.Enum.from_enum(DSTypeEnum, description='枚举类型')
    ds_uri = graphene.String(description='数据地址')
    ds_user = graphene.String(description='用户')
    ds_password = graphene.String(description='密码')
    ds_private = graphene.JSONString(description='私有数据，json')

    def resolve_ds_type(self, info):
        return DSTypeEnum(1)

    # class Meta:
    #     model = UserModel
    #     description = 'Schema的备注'
    #     only_fields = ('name',)  # 仅能获取某些model字段
    #     exclude_fields = ("deleted_at",)  # 隐藏某些model的


class Query(graphene.ObjectType):
    datasources = graphene.List(Datasource, offset=graphene.Int(0), size=graphene.Int(10))

    def resolve_datasources(self, info, **kwargs):
        res = table.search("*").paging(kwargs["offset"], kwargs["size"])
        docs = [d.__dict__ for d in res.docs]
        return docs


app = FastAPI()

app.add_route("/gql", GraphQLApp(schema=graphene.Schema(query=Query)))

uvicorn.run(app, host="0.0.0.0", port=18001)
