# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : Zhang Zhanqi
# @FILE     : yolo_pipelines2.py
# @Time     : 2021/10/12 10:04
"""
    load_data -> train ->
    build -> push

"""
from kfp import dsl, compiler, components, containers, Client
from kubernetes import client as k8s_client


def load_data(data_url: str = '') -> str:
    print(f'down load data -> {data_url}')
    return data_url


def train(msg: str = '') -> str:
    print(f'train data -> {msg}')
    import random
    result = 'image' if random.randint(0, 1) == 0 else 'video'
    return result


load_data_op = components.create_component_from_func(
    func=load_data,
    base_image=components.default_base_image_or_builder,
)

train_op = components.create_component_from_func(
    func=train,
    base_image='192.168.101.66:9080/com.zzq/yolo-interface:5.0.4',
)


def build_op(image: str = '', tag: str = 'latest', server: str = '.', Dockerfile: str = 'Dockerfile'):
    image_name = f'192.168.101.66:9080/{image}:{tag}'
    op = dsl.ContainerOp(
        name='build image',
        image='docker:20.10.9-git',
        command=['sh', '-c'],
        arguments=f'''git clone https://zzq120203%40163.com:struggle.1023@x.gogingko.uk:8029/ai/step/smoking-detect.git && \
                cd smoking-detect && \
                docker build -t {image_name} . && \
                echo {image_name} > /tmp/output_path.txt''',
        file_outputs={'output': '/tmp/output_path.txt'}
    )
    op.add_volume(k8s_client.V1Volume(
        host_path=k8s_client.V1HostPathVolumeSource(path='/var/run/docker.sock'),
        name='docker')
    )
    op.add_volume_mount(k8s_client.V1VolumeMount(
        mount_path='/var/run/docker.sock',
        name='docker')
    )
    op.add_volume(k8s_client.V1Volume(
        host_path=k8s_client.V1HostPathVolumeSource(path=server),
        name='server')
    )
    op.add_volume_mount(k8s_client.V1VolumeMount(
        mount_path='/server',
        name='server')
    )
    # op.add_volume('/var/run/docker.sock:/var/run/docker.sock')
    # op.add_volume(f'{server}:/server')

    return op


def push_op(image: str):
    op = dsl.ContainerOp(
        name='push image',
        image='docker:20.10.9-git',
        command=['sh', '-c'],
        arguments=f'docker login -u zzq -p Ql@ruixin1106 192.168.101.66:9080 && docker push {image}',
    )
    op.add_volume(k8s_client.V1Volume(
        host_path=k8s_client.V1HostPathVolumeSource(path='/var/run/docker.sock'),
        name='docker')
    )
    op.add_volume_mount(k8s_client.V1VolumeMount(
        mount_path='/var/run/docker.sock',
        name='docker')
    )
    # op.add_volume(k8s_client.V1Volume('/var/run/docker.sock:/var/run/docker.sock'))

    return op


@dsl.pipeline(name='yolo-pipeline')
def my_pipeline(
        data_url: str = '',
        image: str = 'com.zzq/yolo',
        tag: str = '1.0.0'
):
    load1 = load_data_op(data_url)
    load1.init_containers = None
    train1 = train_op(load1.output)

    build = build_op(image, tag, train1.output)

    push = push_op(build.output)

    # with dsl.Condition(train1.output == 'video'):
    #     train2 = train_op(load1.output)
    #     build2 = build_op(image, tag, train2)
    #     push2 = push_op(build2.output)


if __name__ == '__main__':
    host = "http://192.168.101.66:8080"

    pipeline_name = "yolo"
    pipeline_package_path = "pipeline.zip"
    version = "1.2.7"

    experiment_name = "my-pipe"
    run_name = "kubeflow yolo test {}".format(version)

    client = Client(host=host)
    compiler.Compiler().compile(my_pipeline, pipeline_package_path)

    pipeline_id = client.get_pipeline_id(pipeline_name)
    if pipeline_id:
        client.upload_pipeline_version(
            pipeline_package_path=pipeline_package_path,
            pipeline_version_name=version,
            pipeline_name=pipeline_name
        )
    else:
        client.upload_pipeline(
            pipeline_package_path=pipeline_package_path,
            pipeline_name=pipeline_name
        )

    experiment = client.create_experiment(name=experiment_name)
    run = client.run_pipeline(experiment.id, run_name, pipeline_package_path)
