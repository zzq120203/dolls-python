# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : Zhang Zhanqi
# @FILE     : test_json.py
# @Time     : 2021/6/30 15:46
from rejson import Path

from dolls.pydis import RedisPool

if __name__ == '__main__':
    redis = RedisPool(urls="192.168.101.66:26379", password="zzq@1023")

    json = redis.json()

    json.delete("test")

    json.insert_update("test", {
        "a": ["a"],
        "b": "b",
        "c": {"1":"1"}
    })

    print(json.jsonget("test"))

    json.insert_append("test",  {
        "a": ["a1"],
        "b": "b1",
        "c": {"2":"2"}
    })

    print(json.jsonget("test"))