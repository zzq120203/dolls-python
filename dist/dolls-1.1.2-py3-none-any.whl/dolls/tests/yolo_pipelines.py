# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : Zhang Zhanqi
# @FILE     : yolo_pipelines.py
# @Time     : 2021/10/12 10:04
"""
    load_data -> train ->
    build -> push

"""
from kfp import dsl, compiler, components, containers, Client


def load_data(data_url: str = '') -> str:
    return data_url


def train(msg: str = '') -> str:
    print(f'train data -> {msg}')
    import random
    result = 'image' if random.randint(0, 1) == 0 else 'video'
    return result


def build(image: str = '', tag: str = 'latest', data_result: str = '') -> str:
    build_image = containers.build_image_from_working_dir(
        image_name=f'192.168.101.66:9080/{image}:{tag}',
        base_image='192.168.101.66:9080/com.zzq/yolo-interface:5.0.4',
    )
    print(f'build image -> {build_image}')
    return build_image


#
# def push(image: str = ''):
#     print(f'push image -> {image}')


load_data_op = components.create_component_from_func(
    func=load_data,
    base_image=components.default_base_image_or_builder,
)

train_op = components.create_component_from_func(
    func=train,
    base_image='192.168.101.66:9080/com.zzq/yolo-interface:5.0.4',
)

build_op = components.create_component_from_func(
    func=build,
    base_image=components.default_base_image_or_builder,
)


# push_op = components.create_component_from_func(
#     func=push,
#     base_image='docker:20.10.9',
# )

def push_op(image: str):
    return dsl.ContainerOp(
        name='push image',
        image='docker:20.10.9',
        command=['sh', '-c'],
        arguments=['docker', 'pull', image]
    )


@dsl.pipeline(name='yolo-pipeline')
def my_pipeline(
        data_url: str = '',
        image: str = 'com.zzq/yolo',
        tag: str = '1.0.0'
):
    load1 = load_data_op(data_url)
    load1.init_containers = None
    train1 = train_op(load1.output)
    build1 = build_op(image, tag, train1.output)

    push = push_op(build1.output)

    with dsl.Condition(train1.output == 'video'):
        train2 = train_op(load1.output)
        build2 = build_op(train2.output)
        push = push_op(build2.output)


if __name__ == '__main__':
    host = "http://192.168.101.66:30786"

    pipeline_name = "yolo"
    pipeline_package_path = "pipeline.zip"
    version = "yolo 1.1.0"

    experiment_name = "my-pipe"
    run_name = "kubeflow study {}".format(version)

    client = Client(host=host)
    compiler.Compiler().compile(my_pipeline, pipeline_package_path)

    pipeline_id = client.get_pipeline_id(pipeline_name)
    if pipeline_id:
        client.upload_pipeline_version(
            pipeline_package_path=pipeline_package_path,
            pipeline_version_name=version,
            pipeline_name=pipeline_name
        )
    else:
        client.upload_pipeline(
            pipeline_package_path=pipeline_package_path,
            pipeline_name=pipeline_name
        )

    experiment = client.create_experiment(name=experiment_name)
    run = client.run_pipeline(experiment.id, run_name, pipeline_package_path)
