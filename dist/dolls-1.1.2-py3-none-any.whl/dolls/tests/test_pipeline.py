# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : Zhang Zhanqi
# @FILE     : test_pipeline.py
# @Time     : 2021/10/8 11:21
import kfp
from kfp import dsl

@dsl.pipeline()
def ss():
    pass


client = kfp.Client(host='http://localhost:30786')
print(client.list_experiments())

client.delete_experiment('08da8beb-1d63-453d-a078-e6b379c97bed')



