# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : sql_test.py
# @Time     : 2022/6/17 15:06
import sqlalchemy

TYPE_RELATION = {
    'varchar': sqlalchemy.String,
    'int': sqlalchemy.Integer,
    'smallint': sqlalchemy.SmallInteger,
    'tinyint': sqlalchemy.SmallInteger,
    'bigint': sqlalchemy.BigInteger,
    'text': sqlalchemy.TEXT
}


def table(name, fields):
    columns = []
    for field in fields:
        column = sqlalchemy.Column(field.get('name'), TYPE_RELATION.get(field.get('type')),
                                   primary_key=field.get('primary_key', False), comment=field.get('comment', None))
        columns.append(column)
    return sqlalchemy.Table(name, sqlalchemy.MetaData(), *columns)


if __name__ == '__main__':
    print(table("test", [{'name': "a1", "type": "int"}]).insert())

