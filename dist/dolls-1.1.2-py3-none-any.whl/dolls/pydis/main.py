if __name__ == '__main__':
    s = ("1", "2")

    a = [("1", "2")]

    print(type(s))

    print(type(a))
